<?php

function httpPost($url, $postData)
{
    $headers = array(
        "Content-type: text/xml;charset=\"utf-8\"",
        "Accept: text/xml",
        "Cache-Control: no-cache",
        "Pragma: no-cache",
        "Content-length: " . strlen($postData),
    );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // the SOAP request
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);

    curl_close($ch);
    return $response;
}

function containOnlyDigits($val) {
  return !preg_match('/[^0-9]/', $val, $matches);
}

$response = array(
  'status' => 'error',
  'message' => 'Неправильный запрос'
);

if (!empty($_POST)) {

  $fieldsName = array(
    'region' => 'Регион',
    'fam' => 'Фамилия',
    'im' => 'Имя',
    'ot' => 'Отчество',
    'dr' => 'Дата рождения',
    'gdr' => 'Год рождения',
    'inn' => 'ИНН',
    'snils' => 'СНИЛС',
    'fb_type' => 'Тип',
    'description' => 'Описание'
  );

  $checkPatterns =  array(
    'region', 'gdr', 'fb_type', 'inn', 'snils'
  );

  $errors = array();

  $im = $_POST['im'];
  $fam = $_POST['fam'];
  $ot = $_POST['ot'];
  $dr = $_POST['dr'];
  $gdr = $_POST['gdr'];
  $inn = $_POST['inn'];
  $snils = $_POST['snils'];
  $region = $_POST['region'];
  $fb_type = $_POST['fb_type'];
  $description = $_POST['description'];
  $session_code = $_POST['SESSION_CODE'];

  foreach ($checkPatterns as $field) {
    if (!containOnlyDigits($$field)) {
      $errors[] = $fieldsName[ $field ] . ' содержит символы, отличные от цифр';
    }
  }

  if ( strlen($inn) != 12 ) {
    $errors[] = 'ИНН введен неправильно, проверьте количество введенных цифр';
  }

  if ( strlen($snils) != 11 ) {
    $errors[] = 'СНИЛС введен неправильно, проверьте количество введенных цифр';
  }

  if ( count($errors) > 0 ) {
    $response['message'] = implode('<br>', $errors);
  } else {
    $response['status'] = 'success';
    $response['message'] = 'Данные успешно отправлены';
  }

  $data = '<?xml version="1.0" encoding="utf-8"?>
    <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:WashOut">
       <soapenv:Header/>
       <soapenv:Body>
          <urn:check_vs soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
            <vs_number xsi:type="xsd:int"></vs_number>
            <id_autorization xsi:type="xsd:int"></id_autorization>
          </urn:check_vs>
       </soapenv:Body>
    </soapenv:Envelope>';
}

echo json_encode($response);

//  $data = '<?xml version="1.0" encoding="utf-8"? > // remove space between ? >
//    <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:WashOut">
//       <soapenv:Header/>
//       <soapenv:Body>
//          <urn:check_vs soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
//            <vs_number xsi:type="xsd:int"></vs_number>
//            <id_autorization xsi:type="xsd:int"></id_autorization>
//          </urn:check_vs>
//       </soapenv:Body>
//    </soapenv:Envelope>';

//$url = 'localhost';
//$a = array();
//var_dump(check($_POST['region'], 'int', $a));
//$res = httpPost($url, $data);
//var_dump($res);


//echo 'Sended data is ' . serialize($_POST);
