$(function(){
  function allRequiredFieldsAreFilled() {
    var r = $('.required'),
        f = true;

    for(var i=0, cnt = r.length; i < cnt && f; i++ ) {
      if (r[i].value.length == 0) {
        console.log(i);
        f = false;
      }
    }

    return f;
  }

  function checkCyr(val) {
    return !/[^а-яА-ЯЁё]/.test(val);
  }

  $('#form1').submit(function(e){
    var sd = $(this).serialize();
    if(allRequiredFieldsAreFilled()) {
      var err = '';

      if (!checkCyr( $('#im').val() )) {
        err += 'В имени присутсвуют запрещенные символы <br>';
      }

      if (!checkCyr( $('#fam').val() )) {
        err += 'В фамилии присутсвуют запрещенные символы <br>';
      }

      if (!checkCyr( $('#ot').val() )) {
        err += 'В отчестве присутсвуют запрещенные символы <br>';
      }

      if ( $('#dr').val().length != 10 ) {
        err += 'Дата рождения указана неверно <br>';
      }

      if ( $('#gdr').val().length != 4 ) {
        err += 'Год рождения указан неверно <br>';
      }

      if ( $('#inn').val().length != 12 ) {
        err += 'ИНН указан неверно <br>';
      }

      if ( $('#snils').val().length != 11 ) {
        err += 'СНИЛС указан неверно <br>';
      }

      if ( $('#region').val().length == 0 || $('#region').val().length > 4 ) {
        err += 'Регион указан неверно <br>';
      }

      if (err.length != 0) {
        $('#resp').html(err);
        return false;
      }

      $.ajax({
        url: 'handler.php',
        type: 'POST',
        data: sd,
        success: function(res) {
          $('#resp').html(res.message);
        }
      });
    }

    e.preventDefault();
    e.stopPropagation();
    return false;
  });

  $('#dr').on("keyup", function(e){
    var value = $(this).val();
    if (value.length > 5) {
      var gdr = value.split('.')[2];
      $('#gdr').val(gdr);
    }
  });

  $('#description').autosize({ append: "\n" });
  $('#inn').mask('999999999999');
  $('#snils').mask('99999999999');
  $('#dr').mask('99.99.9999');
  $('#region').mask('9999');

});
