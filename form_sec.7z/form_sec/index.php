<?php
session_start();
$session_id = session_id();

$i = 0; $is= 1; $ie = 11;
$fb_list = array_combine(range($is, $ie),range($is, $ie));


?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./vendor/css/bootstrap.css" />
    <link rel="stylesheet" href="./assets/app.css" />
    <title>Send Form</title>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <h1>Форма отправки</h1>
          <form class="form" id="form1" name="form1" action="index.php">
            <input type="hidden" name="f" value="fff">
            <div class="form-group">
              <label for="im">Имя</label>
              <input type="text" class="form-control required" id="im" name="im" placeholder="Введите имя" required>
            </div>
            <div class="form-group">
              <label for="fam">Фамилия</label>
              <input type="text" class="form-control required" id="fam" name="fam" placeholder="Введите фамилию" required>
            </div>
            <div class="form-group">
              <label for="ot">Отчество</label>
              <input type="text" class="form-control required" id="ot" name="ot" placeholder="Введите отчество" required>
            </div>
            <div class="form-group">
              <label for="dr">Дата рождения (хх.хх.хххх)</label>
              <input type="text" class="form-control required" id="dr" name="dr" placeholder="Введите день рождения" required>
            </div>
            <div class="form-group">
              <label for="gdr">Год рождения (хххх)</label>
              <input type="text" class="form-control required" id="gdr" name="gdr" placeholder="Введите год рождения" required>
            </div>
            <div class="form-group">
              <label for="inn">ИНН</label>
              <input type="text" class="form-control" id="inn" name="inn" placeholder="Введите ИНН">
            </div>
            <div class="form-group">
              <label for="snils">СНИЛС</label>
              <input type="text" class="form-control" id="snils" name="snils" placeholder="Введите СНИЛС">
            </div>
            <div class="form-group">
              <label for="region">Регион</label>
              <input type="text" class="form-control" id="region" name="region" placeholder="Введите регион">
            </div>
            <div class="form-group">
              <label for="fb_type">Тип</label>
              <select class="form-control required" id="fb_type" name="fb_type" rows="4">
                <?php foreach ($fb_list as $id => $name) {
                  echo '<option value="'. $id .'">' . $name . '</option>';
                } ?>
              </select>
            </div>
            <div class="form-group">
              <label for="description">Описание</label>
              <textarea type="text" class="form-control" id="description" name="description" placeholder="Введите описание" rows="4"></textarea>
            </div>
            <div class="form-group">
              <input type="hidden" name="SESSION_CODE" class="form-control" value="<?php echo $session_id; ?>">
              <button type="submit" class="form-control">Отправить</button>
            </div>
          </form>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="resp"></div>
      </div>
    </div>


<!--    <script src="./vendor/js/jquery.min.js"></script>
    <script src="./vendor/js/bootstrap.min.js"></script>
    <script src="./vendor/js/autoresize.js"></script>--> <!-- https://bootsnipp.com/snippets/P351 -->

    <script src="./vendor/js/bundle.js"></script>

    <script src="./assets/app.js"></script>
  </body>
</html>
